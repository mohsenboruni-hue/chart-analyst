# Changelog

## 2026-09-04 — Controlled engineering repository

- Reorganized current Chart Analyst artifacts into a professional repository layout.
- Preserved production HTML as a baseline; no signal formula changes made.
- Added AI-agent governance and strategy/research control documents.
- Added minimal same-origin read-only API proxy server.
- Added deterministic repository and syntax checks.
- Separated production, research, data, tests, docs, and legacy artifacts.


## 2026-09-04 — Futures leverage extension
- Added futures signal leverage band 1x–20x.
- Added score/ATR gated recommended leverage: 20x/15x/10x/5x/1x.
- Added explicit invariant: leverage does not increase the risk budget or bypass position-notional caps.
- Added standalone browser page: `apps/dashboard/futures-20x.html`.
- This is a research/signal layer only; no live order execution was added.

## 0.2.0 — 2026-09-04
- Added Gold spot/futures analysis adapters.
- Added deterministic 4H construction from four closed 1H Gold candles.
- Added live safety gate and KuCoin V2 signed execution boundary.
- Added real-data acquisition scripts for KuCoin, Bitunix, and Yahoo.
- Added unified live/paper browser monitor.

## 2026-09-04 — Real Research Gate
- Added `research/real/real_research.py` for real OHLCV acquisition, validation, WFA/OOS, cost stress and Monte-Carlo diagnostics.
- Added `research/real/RUN_TERMUX.sh` for execution on network-enabled Termux/Linux.
- Attempted all six real-data acquisitions in this sandbox; all were blocked by DNS/network egress.
- No economic PASS/FAIL and no live authorization claimed.
