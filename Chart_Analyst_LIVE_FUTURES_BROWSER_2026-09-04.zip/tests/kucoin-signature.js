const assert=require('assert');
const {makeHeaders}=require('../execution/kucoin-client');
const h=makeHeaders({key:'k',secret:'s',passphrase:'p',timestamp:1700000000000,method:'POST',path:'/api/test',body:'{"a":1}'});
assert(h['KC-API-KEY']==='k');assert(h['KC-API-KEY-VERSION']==='2');assert(/^[A-Za-z0-9+/]+={0,2}$/.test(h['KC-API-SIGN']));assert(/^[A-Za-z0-9+/]+={0,2}$/.test(h['KC-API-PASSPHRASE']));
console.log('PASS KuCoin V2 signing deterministic shape test');
