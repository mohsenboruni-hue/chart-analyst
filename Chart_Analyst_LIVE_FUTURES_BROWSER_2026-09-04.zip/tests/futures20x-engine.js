#!/usr/bin/env node
const fs=require('fs'), vm=require('vm');
const html=fs.readFileSync('apps/dashboard/index.html','utf8');
const code=html.match(/<script>([\s\S]*?)<\/script>/i)[1];
const cut=code.indexOf('// ---------------------------------------------------------------------------\n// INIT');
if(cut<0) throw new Error('INIT marker missing');
const ctx={console, Math, Date, JSON, Number, String, Object, Array, Set, Map, isFinite, parseFloat, parseInt};
vm.createContext(ctx); vm.runInContext(code.slice(0,cut),ctx);
function tf(trend='BULL',structure='HH_HL',rsi=50,atr=0.5){return {warmupComplete:true,regime:{trend,label:trend},structure,last:{rsi,atr},sr:{majorSupport:null,majorResistance:null}}}
function sig(atr,scoreShape=true){
  const z=tf('BULL','HH_HL',50,atr), h1=tf('BULL',scoreShape?'XX':'XX',50,atr);
  return ctx.buildFuturesSignal({'4h':z,'1h':h1,'15m':z},100);
}
let pass=0,fail=0;function ok(name,v,detail=''){if(v){console.log('PASS',name,detail);pass++}else{console.error('FAIL',name,detail);fail++}}
const a=sig(.5); ok('20x available in low-ATR high-score case',a.recommendedLeverage===20,JSON.stringify(a.leverageBand));
const at=[.5,.7,.71,.93,1,1.4,1.41,2.8,3]; const lev=at.map(x=>sig(x).recommendedLeverage); ok('Leverage is non-increasing as ATR rises',lev.every((v,i)=>i===0||v<=lev[i-1]),lev.join(','));
ok('Hard cap <=20x',lev.every(v=>v>=1&&v<=20),lev.join(','));
ok('20x requires safety guard',a.leverageBand.marginSafetyMaxLeverage>=20 && a.recommendedLeverage===20,JSON.stringify(a.leverageBand));
// risk budget invariant: equity 1000, risk 2%, stop 1.25% -> 800 notional, but cap 50% -> 500.
const equity=1000,risk=.02,stop=.0125,cap=.5; const expected=Math.min(equity*risk/stop,equity*cap); ok('Risk sizing independent of leverage',expected===500,`expectedNotional=${expected}`);
// 20x margin is 25 for 500 notional; changing leverage must not change notional or risk budget.
ok('20x margin arithmetic',expected/20===25,`margin=${expected/20}`);
console.log(`SUMMARY ${pass} PASS / ${fail} FAIL`); process.exit(fail?1:0);
