const assert=require('assert');
const {authorizeOrder}=require('../execution/live-gate');
const env={TRADING_MODE:'live',LIVE_TRADING_ENABLED:'true',LIVE_TRADING_CONFIRM:'I_UNDERSTAND_LIVE_RISK',MAX_LEVERAGE:'20',MAX_RISK_PER_TRADE:'0.02',MAX_ORDER_SIZE:'20'};
assert(authorizeOrder({side:'LONG',symbol:'XBTUSDTM',leverage:20,size:1,riskFraction:.02},env).authorized);
assert(authorizeOrder({side:'SHORT',symbol:'ETHUSDTM',leverage:10,size:2,riskFraction:.01},env).authorized);
assert(!authorizeOrder({side:'SHORT',symbol:'ETHUSDTM',leverage:21,size:1,riskFraction:.01},env).authorized);
assert(!authorizeOrder({side:'LONG',symbol:'XBTUSDTM',leverage:5,size:21,riskFraction:.01},env).authorized);
console.log('PASS live order authorization tests');
