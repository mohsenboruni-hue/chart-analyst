const assert=require('assert');
const {preflight,authorizeOrder}=require('../execution/live-gate');
let p=preflight({TRADING_MODE:'paper'}); assert(p.ok && p.mode==='paper');
let a=authorizeOrder({side:'LONG',leverage:20,riskFraction:0.02},{TRADING_MODE:'paper'}); assert(!a.authorized && a.paper);
p=preflight({TRADING_MODE:'live',LIVE_TRADING_ENABLED:'false',LIVE_TRADING_CONFIRM:'I_UNDERSTAND_LIVE_RISK'}); assert(!p.ok);
p=preflight({TRADING_MODE:'live',LIVE_TRADING_ENABLED:'true',LIVE_TRADING_CONFIRM:'I_UNDERSTAND_LIVE_RISK'}); assert(p.ok);
a=authorizeOrder({side:'LONG',leverage:21,riskFraction:0.01},{TRADING_MODE:'live',LIVE_TRADING_ENABLED:'true',LIVE_TRADING_CONFIRM:'I_UNDERSTAND_LIVE_RISK',MAX_LEVERAGE:'20'}); assert(!a.authorized);
console.log('PASS live safety gate tests');
