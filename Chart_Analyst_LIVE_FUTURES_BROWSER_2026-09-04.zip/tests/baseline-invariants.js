#!/usr/bin/env node
const fs=require('fs');
const prod=fs.readFileSync('apps/dashboard/index.html','utf8');
const bt=fs.readFileSync('research/runner/backtest.html','utf8');
const checks=[
 ['spot signal',prod,/function buildSignal\s*\(/],
 ['futures signal',prod,/function buildFuturesSignal\s*\(/],
 ['15m/1h/4h',prod,/"4h"[\s\S]*"1h"[\s\S]*"15m"/],
 ['next-open backtest',bt,/btSignalAt\([\s\S]*?i\+1/],
 ['2.5 ATR futures SL',prod,/2\.5\*atr/],
 ['futures leverage max 20x',prod,/recommendedLeverage[\s\S]*?Math\.min\(20/],
 ['futures leverage risk capped',prod,/MAX_20X_RISK_CAPPED_WITH_MARGIN_SAFETY_GUARD/],
 ['futures confidence index',prod,/confidencePct[\s\S]*?confidenceType/],
 ['futures margin safety guard',prod,/marginSafetyMaxLeverage[\s\S]*?Math\.floor\(\(35 \+ 1e-9\) \/ stopDistancePct\)/],
 ['no API key literal',prod,/(?!api[_-]?key\s*[:=]\s*["'][^"']+["'])/i]
];
let fail=0;
for(const [name,text,re] of checks){
  const ok=name==='no API key literal' ? !/api[_-]?key\s*[:=]\s*["'][^"']+["']/i.test(text) : re.test(text);
  if(ok) console.log('PASS '+name); else {console.error('FAIL '+name);fail++;}
}
process.exit(fail?1:0);
