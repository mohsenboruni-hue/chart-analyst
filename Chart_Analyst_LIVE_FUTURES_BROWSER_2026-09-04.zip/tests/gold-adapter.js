const assert=require('assert');
const {GOLD_MARKETS,normalizeYahooChart}=require('../engine/market/gold');
assert(GOLD_MARKETS.GOLD_SPOT.symbol==='XAUUSD=X');
assert(GOLD_MARKETS.GOLD_FUTURES.symbol==='GC=F');
const raw={chart:{result:[{timestamp:[1000,1900],indicators:{quote:[{open:[100,101],high:[102,103],low:[99,100],close:[101,102],volume:[10,11]}]}}]}};
const rows=normalizeYahooChart(raw,'15m'); assert.equal(rows.length,2); assert.equal(rows[0].close,101);
console.log('PASS gold adapter tests');
