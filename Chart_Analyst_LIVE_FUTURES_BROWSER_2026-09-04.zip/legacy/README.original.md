# Chart Analyst — Gold + Futures + Tabdeal

- `index.html`: dashboard
- `backtest.html`: historical signal backtest using the same production signal functions
- `server.js`: same-origin read-only proxies for KuCoin, Bitunix and Tabdeal
- `start.sh`: Termux launcher

Open `http://127.0.0.1:8080/` for the dashboard and `http://127.0.0.1:8080/backtest.html` for the historical backtest.

Backtest assumptions are explicit in the UI and are not a claim of live profitability. No orders or API keys are used.
