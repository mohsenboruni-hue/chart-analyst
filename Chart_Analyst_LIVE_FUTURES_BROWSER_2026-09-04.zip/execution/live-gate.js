/**
 * Explicit live-trading authorization boundary.
 * Live orders are permitted only when the operator explicitly enables live mode
 * and supplies the exact confirmation phrase. Credentials remain server-side.
 */
function readLiveConfig(env=process.env){
  return {
    enabled: env.LIVE_TRADING_ENABLED === 'true',
    confirm: env.LIVE_TRADING_CONFIRM === 'I_UNDERSTAND_LIVE_RISK',
    mode: env.TRADING_MODE || 'paper',
    maxLeverage: Math.min(20, Math.max(1, Number(env.MAX_LEVERAGE || 20))),
    maxRiskPerTrade: Math.min(0.02, Math.max(0, Number(env.MAX_RISK_PER_TRADE || 0.02))),
    maxOrderSize: Math.max(1, Number(env.MAX_ORDER_SIZE || 20)),
    killSwitch: env.LIVE_KILL_SWITCH === 'true'
  };
}
function preflight(env=process.env){
  const c=readLiveConfig(env); const reasons=[];
  if(c.mode==='live' && !c.enabled) reasons.push('LIVE_TRADING_ENABLED is false');
  if(c.mode==='live' && !c.confirm) reasons.push('LIVE_TRADING_CONFIRM is missing');
  if(c.killSwitch) reasons.push('LIVE_KILL_SWITCH is active');
  return {ok: reasons.length===0, mode:c.mode, reasons, config:c};
}
function authorizeOrder(order, env=process.env){
  const p=preflight(env);
  if(!p.ok) return {authorized:false,reasons:p.reasons};
  if(!order || !['LONG','SHORT'].includes(order.side)) return {authorized:false,reasons:['invalid side']};
  const lev=Number(order.leverage||1), risk=Number(order.riskFraction||0), size=Number(order.size||0);
  if(p.mode==='live'){
    if(!Number.isInteger(size) || size<1) return {authorized:false,reasons:['futures size must be a positive integer contract count']};
    if(size>p.config.maxOrderSize) return {authorized:false,reasons:['order size exceeds configured cap']};
  }
  if(lev<1 || lev>p.config.maxLeverage) return {authorized:false,reasons:['order leverage exceeds configured cap']};
  if(risk>p.config.maxRiskPerTrade) return {authorized:false,reasons:['order risk exceeds configured cap']};
  return {authorized:p.mode==='live',paper:p.mode!=='live',reasons:p.mode==='live'?[]:['paper mode: no live submission']};
}
module.exports={readLiveConfig,preflight,authorizeOrder};
