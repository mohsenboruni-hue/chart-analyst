/** KuCoin Classic Futures REST client.
 * Credentials never enter the browser. Browser -> local server -> KuCoin.
 * Futures order symbols are KuCoin contract symbols such as XBTUSDTM/ETHUSDTM.
 */
const crypto=require('crypto'),https=require('https');
function b64hmac(secret,msg){return crypto.createHmac('sha256',secret).update(msg).digest('base64');}
function makeHeaders({key,secret,passphrase,keyVersion='2',timestamp,method,path,body=''}){
  const sign=b64hmac(secret,`${timestamp}${method.toUpperCase()}${path}${body}`);
  const pp=b64hmac(secret,passphrase);
  return {'KC-API-KEY':key,'KC-API-SIGN':sign,'KC-API-TIMESTAMP':String(timestamp),'KC-API-PASSPHRASE':pp,'KC-API-KEY-VERSION':String(keyVersion),'Content-Type':'application/json'};
}
function request({baseUrl='https://api-futures.kucoin.com',key,secret,passphrase,keyVersion='2',method='POST',path,bodyObj}){
  const body=bodyObj?JSON.stringify(bodyObj):''; const ts=Date.now();
  const headers=makeHeaders({key,secret,passphrase,keyVersion,timestamp:ts,method,path,body});
  return new Promise((resolve,reject)=>{
    const u=new URL(baseUrl+path);
    const req=https.request(u,{method,headers},res=>{let data='';res.on('data',d=>data+=d);res.on('end',()=>{let j;try{j=JSON.parse(data)}catch(e){return reject(new Error(`KuCoin non-JSON HTTP ${res.statusCode}`))}if(res.statusCode<200||res.statusCode>=300)return reject(new Error(`KuCoin HTTP ${res.statusCode}: ${JSON.stringify(j)}`));if(j.code&&j.code!=='200000')return reject(new Error(`KuCoin API ${j.code}: ${JSON.stringify(j)}`));resolve(j)})});
    req.on('error',reject); if(body)req.write(body); req.end();
  });
}
const ALLOWED_FUTURES=new Set(['XBTUSDTM','ETHUSDTM']);
function createClient(env=process.env){return {
  placeFuturesOrder: async (order)=>{
    const {authorizeOrder}=require('./live-gate'); const auth=authorizeOrder(order,env);
    if(!auth.authorized) throw new Error('LIVE ORDER BLOCKED: '+auth.reasons.join('; '));
    if(!env.KC_API_KEY||!env.KC_API_SECRET||!env.KC_API_PASSPHRASE) throw new Error('LIVE ORDER BLOCKED: missing KuCoin credentials');
    if(!ALLOWED_FUTURES.has(order.symbol)) throw new Error('LIVE ORDER BLOCKED: symbol is not in the verified futures allowlist');
    const side=order.side==='LONG'?'buy':'sell';
    const body={clientOid:order.clientOid||crypto.randomUUID(),symbol:order.symbol,marginMode:order.marginMode||'ISOLATED',leverage:Number(order.leverage||1),positionSide:order.positionSide||'BOTH',side,type:order.orderType||'market',size:Number(order.size),reduceOnly:!!order.reduceOnly,timeInForce:'GTC',remark:'ChartAnalyst-LIVE'};
    return request({key:env.KC_API_KEY,secret:env.KC_API_SECRET,passphrase:env.KC_API_PASSPHRASE,keyVersion:env.KC_API_KEY_VERSION||'2',path:'/api/v1/orders',bodyObj:body});
  }
};}
module.exports={b64hmac,makeHeaders,request,createClient,ALLOWED_FUTURES};
