const http=require('http'),https=require('https'),fs=require('fs'),path=require('path');const {URL}=require('url');
const ROOT=__dirname;
function loadDotEnv(file){try{const txt=fs.readFileSync(file,'utf8');for(const line of txt.split(/\r?\n/)){const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);if(!m||process.env[m[1]]!==undefined)continue;let v=m[2];if((v.startsWith('\"')&&v.endsWith('\"'))||(v.startsWith("'")&&v.endsWith("'")))v=v.slice(1,-1);process.env[m[1]]=v;}}catch(_){}}
loadDotEnv(path.join(ROOT,'.env')); loadDotEnv(path.join(ROOT,'.env.local'));
const PORT=Number(process.env.PORT||8080),HOST=process.env.HOST||'127.0.0.1';
const routes={'/api/kucoin':'https://api.kucoin.com','/api/bitunix':'https://fapi.bitunix.com','/api/tabdeal':'https://api1.tabdeal.org/r/api/v1','/api/yahoo':'https://query1.finance.yahoo.com/v8/finance'};
function proxy(req,res,prefix,base){const u=new URL(req.url.slice(prefix.length)||'/',base),c=u.protocol==='https:'?https:http;const q=c.request(u,{method:'GET',headers:{'User-Agent':'Chart-Analyst/1.0','Accept':'application/json'}},up=>{res.statusCode=up.statusCode||502;for(const[k,v]of Object.entries(up.headers))if(k.toLowerCase()!=='content-encoding')res.setHeader(k,v);up.pipe(res)});q.on('error',e=>{res.statusCode=502;res.setHeader('Content-Type','application/json');res.end(JSON.stringify({error:e.message}))});q.end()}
function safe(url){const d=decodeURIComponent(url.split('?')[0]),rel=d==='/site-home.html'?'/apps/dashboard/site-home.html':(d==='/'||d==='/index.html'?'/apps/dashboard/index.html':d),c=path.resolve(ROOT,'.'+rel);return c.startsWith(ROOT+path.sep)?c:null}
http.createServer((req,res)=>{
  if(req.method==='POST' && req.url==='/api/live-order'){
    const {preflight}=require('./execution/live-gate'); const {createClient}=require('./execution/kucoin-client');
    const pf=preflight(process.env); res.setHeader('Content-Type','application/json');
    if(!pf.ok) {res.statusCode=403; return res.end(JSON.stringify({ok:false,error:'LIVE_GATE_BLOCKED',reasons:pf.reasons}));}
    let raw=''; req.on('data',d=>{raw+=d;if(raw.length>10000)req.destroy()}); req.on('end',async()=>{
      try{const body=JSON.parse(raw||'{}');
        if(body.confirmPhrase!=='SEND_REAL_ORDER') throw new Error('Explicit browser confirmation phrase is required');
        if(body.market!=='futures') throw new Error('Only futures live orders are enabled by this endpoint');
        const order={side:body.side,symbol:body.symbol,leverage:body.leverage,size:body.size,riskFraction:body.riskFraction,marginMode:body.marginMode,positionSide:body.positionSide,reduceOnly:body.reduceOnly,orderType:'market'};
        const result=await createClient(process.env).placeFuturesOrder(order);
        res.statusCode=200; res.end(JSON.stringify({ok:true,order:result,request:{side:order.side,symbol:order.symbol,leverage:order.leverage,size:order.size}}));
      }catch(e){res.statusCode=400;res.end(JSON.stringify({ok:false,error:e.message}));}
    }); return;
  }
  if(req.method!=='GET'){res.statusCode=405;return res.end('GET only')}
  if(req.url==='/api/live-preflight'){const {preflight}=require('./execution/live-gate');res.setHeader('Content-Type','application/json');return res.end(JSON.stringify(preflight(process.env)))}
  for(const[p,b]of Object.entries(routes))if(req.url===p||req.url.startsWith(p+'/'))return proxy(req,res,p,b);const f=safe(req.url);if(!f||!fs.existsSync(f)||!fs.statSync(f).isFile()){res.statusCode=404;return res.end('Not found')}const ext=path.extname(f),type=ext==='.html'?'text/html; charset=utf-8':ext==='.js'?'text/javascript; charset=utf-8':'application/octet-stream';res.setHeader('Content-Type',type);fs.createReadStream(f).pipe(res)}).listen(PORT,HOST,()=>console.log(`Chart Analyst server: http://${HOST}:${PORT}`));
