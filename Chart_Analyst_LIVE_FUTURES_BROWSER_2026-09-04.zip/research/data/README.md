# Real Data Acquisition

These scripts are the canonical acquisition layer for research. They never place orders.

- `kucoin-downloader.py`: BTC/ETH spot, 15m/1h/4h.
- `bitunix-downloader.py`: BTC/ETH perpetual futures, 15m/1h/4h.
- `yahoo-downloader.py`: Gold spot `XAUUSD=X` and continuous gold futures `GC=F`; also BTC/ETH spot reference.

Run in Termux/Linux with network access. Store raw output under `data/raw/` and do not modify downloaded files during validation.
