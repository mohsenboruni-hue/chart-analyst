#!/usr/bin/env python3
"""Download KuCoin spot OHLCV. Public endpoint; no credentials."""
import argparse,json,time,urllib.parse,urllib.request
from pathlib import Path
SYMBOLS={'BTC':'BTC-USDT','ETH':'ETH-USDT'}
TF={'15m':'15min','1h':'1hour','4h':'4hour'}
def fetch(symbol,tf,start,end):
    q=urllib.parse.urlencode({'symbol':symbol,'type':TF[tf],'startAt':start,'endAt':end})
    url='https://api.kucoin.com/api/v1/market/candles?'+q
    req=urllib.request.Request(url,headers={'User-Agent':'Chart-Analyst-Research/1.0','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as r:return json.load(r)
def main(a):
    step={'15m':900,'1h':3600,'4h':14400}[a.interval];end=int(time.time());start=end-a.bars*step*2
    raw=fetch(SYMBOLS[a.asset],a.interval,start,end);rows=[]
    for x in raw.get('data',[]):
        # KuCoin: [time, open, close, high, low, volume, turnover]
        rows.append({'timestamp':int(x[0])*1000,'open':float(x[1]),'close':float(x[2]),'high':float(x[3]),'low':float(x[4]),'volume':float(x[5])})
    rows=sorted(rows,key=lambda r:r['timestamp'])[-a.bars:];o=Path(a.out);o.parent.mkdir(parents=True,exist_ok=True);o.write_text(json.dumps({'asset':a.asset,'market':'spot','provider':'KuCoin','symbol':SYMBOLS[a.asset],'interval':a.interval,'downloaded_at':int(time.time()*1000),'rows':rows},indent=2),encoding='utf-8');print(f'PASS {a.asset} spot {a.interval}: {len(rows)} rows -> {o}')
p=argparse.ArgumentParser();p.add_argument('--asset',choices=SYMBOLS,required=True);p.add_argument('--interval',choices=TF,default='15m');p.add_argument('--bars',type=int,default=1000);p.add_argument('--out',required=True);main(p.parse_args())
