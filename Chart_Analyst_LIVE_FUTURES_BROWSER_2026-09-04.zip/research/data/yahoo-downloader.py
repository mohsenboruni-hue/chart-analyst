#!/usr/bin/env python3
"""Download analysis candles from Yahoo Finance chart API.
No credentials are embedded. Intended for Termux/Linux with network access.
Symbols: BTC-USD, ETH-USD, XAUUSD=X (spot), GC=F (gold futures).
"""
import argparse, json, time, urllib.parse, urllib.request
from pathlib import Path

MAP={
 'BTC_SPOT':'BTC-USD','ETH_SPOT':'ETH-USD','GOLD_SPOT':'XAUUSD=X','GOLD_FUTURES':'GC=F'

}

def fetch(symbol, interval, range_):
    q=urllib.parse.urlencode({'interval':interval,'range':range_})
    url=f'https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(symbol,safe="")}?{q}'
    req=urllib.request.Request(url,headers={'User-Agent':'Chart-Analyst-Research/1.0','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as r: return json.load(r)

def normalize(raw):
    result=raw['chart']['result'][0]; ts=result['timestamp']; q=result['indicators']['quote'][0]
    rows=[]
    for i,t in enumerate(ts):
        row={'timestamp':t*1000,'open':q['open'][i],'high':q['high'][i],'low':q['low'][i],'close':q['close'][i],'volume':q.get('volume',[0]*len(ts))[i] or 0}
        if all(isinstance(row[k],(int,float)) for k in ('open','high','low','close')): rows.append(row)
    return rows

p=argparse.ArgumentParser(); p.add_argument('--asset',choices=MAP); p.add_argument('--interval',default='15m'); p.add_argument('--range',default='60d'); p.add_argument('--out',required=True); a=p.parse_args()
raw=fetch(MAP[a.asset],a.interval,a.range); rows=normalize(raw)
out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps({'asset':a.asset,'provider':'Yahoo Finance chart','symbol':MAP[a.asset],'interval':a.interval,'range':a.range,'downloaded_at':int(time.time()*1000),'rows':rows},indent=2),encoding='utf-8')
print(f'PASS {a.asset}: {len(rows)} rows -> {out}')
