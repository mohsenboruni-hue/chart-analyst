#!/usr/bin/env python3
"""Download Bitunix perpetual futures candles for BTC/ETH.
Uses only public market-data endpoints; no credentials and no orders.
"""
import argparse,json,time,urllib.parse,urllib.request
from pathlib import Path
SYMBOLS={'BTC':'BTCUSDT','ETH':'ETHUSDT'}

def fetch(symbol,interval,end_ms=None,limit=200):
    q={'symbol':symbol,'interval':interval,'limit':min(200,limit),'type':'LAST_PRICE'}
    if end_ms is not None:q['endTime']=str(end_ms)
    url='https://fapi.bitunix.com/api/v1/futures/market/kline?'+urllib.parse.urlencode(q)
    req=urllib.request.Request(url,headers={'User-Agent':'Chart-Analyst-Research/1.0','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as r:return json.load(r)

def collect(symbol,interval,needed):
    out=[];seen=set();end=int(time.time()*1000)
    for _ in range((needed+199)//200+2):
        raw=fetch(symbol,interval,end,200); rows=raw.get('data',[])
        if not rows:break
        mn=None
        for x in rows:
            t=int(x['time']);mn=t if mn is None else min(mn,t)
            if t not in seen:
                seen.add(t);out.append({'timestamp':t,'open':float(x['open']),'high':float(x['high']),'low':float(x['low']),'close':float(x['close']),'volume':float(x.get('baseVol',0))})
        if mn is None or mn>=end:break
        end=mn-1
        if len(rows)<200:break
    return sorted(out,key=lambda x:x['timestamp'])[-needed:]

p=argparse.ArgumentParser();p.add_argument('--asset',choices=SYMBOLS,required=True);p.add_argument('--interval',choices=['15m','1h','4h'],default='15m');p.add_argument('--bars',type=int,default=1000);p.add_argument('--out',required=True);a=p.parse_args()
rows=collect(SYMBOLS[a.asset],a.interval,a.bars);o=Path(a.out);o.parent.mkdir(parents=True,exist_ok=True);o.write_text(json.dumps({'asset':a.asset,'market':'futures_perpetual','provider':'Bitunix','symbol':SYMBOLS[a.asset],'interval':a.interval,'downloaded_at':int(time.time()*1000),'rows':rows},indent=2),encoding='utf-8');print(f'PASS {a.asset} futures {a.interval}: {len(rows)} rows -> {o}')
