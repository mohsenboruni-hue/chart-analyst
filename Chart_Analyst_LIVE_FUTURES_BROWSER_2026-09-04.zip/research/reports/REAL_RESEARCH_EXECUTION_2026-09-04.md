# Chart Analyst — Real Research Execution Report
Date: 2026-09-04

## Objective
Execute real-market data acquisition and research for:
- BTC Spot / BTC Futures
- ETH Spot / ETH Futures
- Gold Spot (XAUUSD=X) / Gold Futures (GC=F)

Research protocol:
1. Real OHLCV acquisition
2. Data validation
3. Baseline reproduction
4. Chronological walk-forward research
5. OOS evaluation
6. 1x/1.5x/2x/3x transaction-cost stress
7. Parameter perturbation
8. Monte-Carlo trade-order stress
9. Final holdout before any promotion

## Execution result in this environment
The real-data acquisition stage was attempted for all six markets.
All six were BLOCKED by the execution sandbox's outbound DNS/network restriction:
`Temporary failure in name resolution`.

Therefore:
- no real-market performance number is reported;
- no Win Rate, CAGR, Sharpe, Profit Factor or Max Drawdown is fabricated;
- no WFA/OOS PASS is claimed;
- no Live Trading authorization is granted.

## Provider contract
BTC/ETH Spot research uses KuCoin public klines.
BTC/ETH Futures research uses Bitunix perpetual-futures public klines.
Gold research uses Yahoo Finance chart data for XAUUSD=X and GC=F.

KuCoin's current official documentation states Spot Klines can be paged historically and returns up to 1,500 records per request; its UTA documentation states Futures intervals under 8h have historical availability after 2025-01-01. The dedicated Futures API documents up to 500 records per request. These limits are handled by the acquisition layer rather than assumed away.

## Offline verification
Repository verification completed successfully:
- structural/syntax checks: PASS
- production signal invariants: PASS
- futures 20x tests: PASS
- Gold adapter tests: PASS
- live safety gate tests: PASS
- KuCoin signing-shape test: PASS

The new real-research runner also passed Python compilation and a deterministic synthetic-data validation/backtest smoke test.

## Promotion decision
**INCONCLUSIVE / NO-GO** for real-money trading.

The engineering system is testable and the acquisition/research pipeline is prepared, but the economic evidence gate cannot pass until the real datasets are downloaded in an environment with network access and the resulting immutable datasets are hashed/frozen.

## Termux execution
From the repository root on a network-enabled Termux/Linux environment:

`bash research/real/RUN_TERMUX.sh 60`

For crypto, 180+ days is preferable where the venue's API history supports it. Gold 15m intraday history may be constrained by the upstream provider; do not silently extend it beyond what the provider actually returns.

After execution, inspect:
- `research/real/results/research_results.json`
- `research/real/results/*.json`

Only after those artifacts exist should WFA/OOS metrics be considered evidence.
