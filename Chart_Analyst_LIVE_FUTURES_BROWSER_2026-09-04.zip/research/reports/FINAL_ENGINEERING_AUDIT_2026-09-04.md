# Chart Analyst — Final Engineering Audit
Date: 2026-09-04
Version: V2-FUTURES20X engineering candidate

## 1. Scope
This audit covers repository integrity, production signal invariants, Futures leverage policy up to 20x, browser deliverables, backtest page syntax, and deterministic risk tests.

## 2. Evidence
- Repository contract: PASS
- Production functions present: `analyzeTimeframe`, `buildSignal`, `buildFuturesSignal`
- Spot/Futures signal domains: PASS
- 15m/1h/4h architecture: PASS
- Next-15m-open backtest boundary: PASS
- Futures 2.5×ATR stop ordering: PASS
- Futures leverage hard cap <=20x: PASS
- Margin-safety guard: PASS
- Signal-quality percentage field: PASS
- API-key literal safety check: PASS
- All HTML inline JavaScript syntax: PASS
- Browser HTTP routes: PASS on local server

## 3. Deterministic Futures 20x experiment
Synthetic high-quality Futures signal, price=100, ATR=0.5:
- Decision: LONG
- Score: 100/100
- Confidence index: 100%
- Stop distance: 1.25%
- Margin safety maximum leverage: 28x
- System maximum: 20x
- Recommended leverage: 20x

ATR sweep with otherwise identical high-quality signal:

| ATR | Recommended leverage | Safety max |
|---:|---:|---:|
| 0.50% | 20x | 28x |
| 0.70% | 20x | 20x |
| 0.71% | 15x | 19x |
| 0.93% | 15x | 15x |
| 1.00% | 10x | 14x |
| 1.40% | 10x | 10x |
| 1.41% | 5x | 9x |
| 2.80% | 5x | 5x |
| 3.00% | 1x | 4x |

The monotonic property held: leverage never increased as ATR increased.

## 4. Risk arithmetic experiment
Example:
- Equity = $1,000
- Risk budget = 2% = $20
- Stop distance = 1.25%
- Risk-derived notional = $1,600
- Max-notional cap = 50% = $500
- Final notional = $500
- At 20x, required initial margin = $25

Changing leverage does not change the risk-derived notional or risk budget. However, leverage can change liquidation sensitivity; therefore the margin-safety guard is mandatory.

## 5. Confidence interpretation
`confidencePct` is currently an engineering **signal-quality index**, not a statistical probability. A value of 100% does NOT mean a 100% chance of profit.

A statistically meaningful win-probability/confidence estimate requires a frozen historical dataset with out-of-sample observations. No such estimate is claimed in this audit.

## 6. Real-market backtest
Status: NOT VERIFIED in this environment.
Reason: public exchange API network/DNS access is unavailable to the build environment.
Therefore this audit intentionally reports no fabricated CAGR, P&L, win rate, Sharpe, or drawdown.

## 7. Known production boundary
The 20x policy is an engineering candidate only. It is not an authorization for live execution. Before production:
1. Verify exact venue contract specifications.
2. Verify maintenance margin and liquidation formula.
3. Include funding and taker/maker fees.
4. Run chronological WFA/OOS.
5. Run 1x/1.5x/2x/3x cost stress.
6. Run parameter perturbation.
7. Run Monte Carlo path/order stress.
8. Run untouched final holdout.
9. Re-run regression suite.

## 8. Decision
Repository / deterministic engineering layer: PASS.
Real-market strategy performance: INCONCLUSIVE / NOT VERIFIED.
20x live trading readiness: FAIL (blocked by missing venue-specific liquidation verification and missing real-data OOS evidence).
Promotion to production: BLOCKED.
