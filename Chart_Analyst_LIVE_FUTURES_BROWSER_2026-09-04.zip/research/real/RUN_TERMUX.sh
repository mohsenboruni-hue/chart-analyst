#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../.."
mkdir -p research/real/results
python research/real/real_research.py --days "${1:-60}" --out research/real/results/research_results.json
