#!/usr/bin/env python3
"""Real-market research runner for Chart Analyst.

Downloads 15m OHLCV, validates it, derives 1h/4h, runs a chronological
walk-forward research/backtest, cost stress and Monte-Carlo trade-order stress.
It never places orders. Intended for Termux/Linux where outbound HTTPS works.
"""
import argparse, json, math, os, random, statistics, sys, time, urllib.parse, urllib.request
from dataclasses import dataclass
from pathlib import Path

UA='Chart-Analyst-Research/2.0'
TF_MS={'15m':900_000,'1h':3_600_000,'4h':14_400_000}

ASSETS={
 'BTC_SPOT':('kucoin','BTC-USDT'), 'ETH_SPOT':('kucoin','ETH-USDT'),
 'BTC_FUTURES':('bitunix','BTCUSDT'), 'ETH_FUTURES':('bitunix','ETHUSDT'),
 'GOLD_SPOT':('yahoo','XAUUSD=X'), 'GOLD_FUTURES':('yahoo','GC=F')}


def get_json(url, timeout=30):
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as r: return json.load(r)


def fetch_kucoin(symbol, start_ms, end_ms):
    out=[]; end=end_ms//1000; step=900
    while end*1000>start_ms:
        start=max(start_ms//1000,end-1400*step)
        q=urllib.parse.urlencode({'symbol':symbol,'type':'15min','startAt':start,'endAt':end})
        raw=get_json('https://api.kucoin.com/api/v1/market/candles?'+q)
        rows=raw.get('data',[]) if isinstance(raw,dict) else []
        if not rows: break
        for x in rows:
            t=int(x[0])*1000
            if start_ms<=t<end_ms: out.append({'t':t,'o':float(x[1]),'c':float(x[2]),'h':float(x[3]),'l':float(x[4]),'v':float(x[5])})
        mn=min(int(x[0]) for x in rows)
        if mn>=end: break
        end=mn-1
        if len(rows)<2: break
        time.sleep(.12)
    return dedup(sorted(out,key=lambda x:x['t']))


def fetch_bitunix(symbol,start_ms,end_ms):
    out=[]; end=end_ms
    while end>start_ms:
        q=urllib.parse.urlencode({'symbol':symbol,'interval':'15m','limit':200,'type':'LAST_PRICE','endTime':end})
        raw=get_json('https://fapi.bitunix.com/api/v1/futures/market/kline?'+q)
        rows=raw.get('data',[]) if isinstance(raw,dict) else []
        if not rows: break
        for x in rows:
            t=int(x['time'])
            if start_ms<=t<end_ms: out.append({'t':t,'o':float(x['open']),'c':float(x['close']),'h':float(x['high']),'l':float(x['low']),'v':float(x.get('baseVol',0))})
        mn=min(int(x['time']) for x in rows)
        if mn>=end: break
        end=mn-1
        if len(rows)<2: break
        time.sleep(.12)
    return dedup(sorted(out,key=lambda x:x['t']))


def fetch_yahoo(symbol,start_ms,end_ms):
    q=urllib.parse.urlencode({'period1':start_ms//1000,'period2':end_ms//1000,'interval':'15m','events':'history'})
    url='https://query1.finance.yahoo.com/v8/finance/chart/'+urllib.parse.quote(symbol,safe='')+'?'+q
    raw=get_json(url); r=raw['chart']['result'][0]; qv=r['indicators']['quote'][0]
    out=[]
    for i,t in enumerate(r['timestamp']):
        vals=[qv[k][i] for k in ('open','high','low','close')]
        if all(v is not None and math.isfinite(float(v)) for v in vals):
            out.append({'t':int(t)*1000,'o':float(vals[0]),'h':float(vals[1]),'l':float(vals[2]),'c':float(vals[3]),'v':float((qv.get('volume') or [0]*len(r['timestamp']))[i] or 0)})
    return dedup(sorted(out,key=lambda x:x['t']))


def dedup(a):
    d={x['t']:x for x in a}; return [d[k] for k in sorted(d)]


def validate(rows,tf='15m'):
    errs=[]; dup=0; gaps=0; prev=None; clean=[]
    step=TF_MS[tf]
    for x in rows:
        if not all(math.isfinite(x[k]) for k in ('o','h','l','c','v')) or min(x['o'],x['h'],x['l'],x['c'])<=0: errs.append('nonfinite_or_nonpositive'); continue
        if x['h']<max(x['o'],x['c']) or x['l']>min(x['o'],x['c']) or x['h']<x['l']: errs.append('ohlc_inconsistent'); continue
        if prev is not None:
            dt=x['t']-prev
            if dt==0: dup+=1
            elif dt!=step: gaps+=1
        prev=x['t']; clean.append(x)
    return {'rows':len(clean),'duplicates':dup,'gaps':gaps,'errors':len(errs),'first':clean[0]['t'] if clean else None,'last':clean[-1]['t'] if clean else None},clean


def resample(rows,ms):
    buckets={}
    for x in rows:
        b=(x['t']//ms)*ms; buckets.setdefault(b,[]).append(x)
    out=[]
    for b,a in sorted(buckets.items()):
        a=sorted(a,key=lambda z:z['t']);
        out.append({'t':b,'o':a[0]['o'],'h':max(z['h'] for z in a),'l':min(z['l'] for z in a),'c':a[-1]['c'],'v':sum(z['v'] for z in a)})
    return out


def ema(vals,p):
    out=[float('nan')]*len(vals)
    if len(vals)<p:return out
    s=sum(vals[:p])/p; out[p-1]=s; k=2/(p+1)
    for i in range(p,len(vals)): s=vals[i]*k+s*(1-k); out[i]=s
    return out

def rsi(vals,p=14):
    out=[float('nan')]*len(vals)
    if len(vals)<=p:return out
    gains=[max(0,vals[i]-vals[i-1]) for i in range(1,len(vals))]; losses=[max(0,vals[i-1]-vals[i]) for i in range(1,len(vals))]
    ag=sum(gains[:p])/p; al=sum(losses[:p])/p
    out[p]=100 if al==0 else 100-100/(1+ag/al)
    for j in range(p,len(gains)):
        ag=(ag*(p-1)+gains[j])/p; al=(al*(p-1)+losses[j])/p
        out[j+1]=100 if al==0 else 100-100/(1+ag/al)
    return out

def atr(rows,p=14):
    out=[float('nan')]*len(rows); trs=[]
    for i,x in enumerate(rows):
        tr=x['h']-x['l'] if i==0 else max(x['h']-x['l'],abs(x['h']-rows[i-1]['c']),abs(x['l']-rows[i-1]['c']))
        trs.append(tr)
    if len(rows)<=p:return out
    a=sum(trs[1:p+1])/p; out[p]=a
    for i in range(p+1,len(rows)): a=(a*(p-1)+trs[i])/p; out[i]=a
    return out

def swings(rows,lb=5):
    hi=[];lo=[]
    for i in range(lb,len(rows)-lb):
        h=rows[i]['h']; l=rows[i]['l']
        if h>=max(x['h'] for x in rows[i-lb:i+lb+1]): hi.append((i,h))
        if l<=min(x['l'] for x in rows[i-lb:i+lb+1]): lo.append((i,l))
    return hi,lo

def structure(rows):
    hi,lo=swings(rows); hs=[p for _,p in hi[-4:]]; ls=[p for _,p in lo[-4:]]
    if len(hs)<2 or len(ls)<2:return 'UNDEFINED'
    if hs[-1]>hs[-2] and ls[-1]>ls[-2]:return 'HH_HL'
    if hs[-1]<hs[-2] and ls[-1]<ls[-2]:return 'LH_LL'
    if abs(hs[-1]-hs[-2])/hs[-2]>.01 or abs(ls[-1]-ls[-2])/ls[-2]>.01:return 'EXPANSION'
    return 'CONTRACTION'


def analysis(rows):
    c=[x['c'] for x in rows]; e20=ema(c,20); e50=ema(c,50); e200=ema(c,200); rr=rsi(c); aa=atr(rows); i=len(rows)-1
    if i<0 or any(math.isnan(z[i]) for z in (e20,e50,e200,rr,aa)): return None
    gap=abs(e20[i]-e50[i])/e50[i]; trend='RANGE'
    if e20[i]>e50[i]>e200[i] and c[i]>e50[i] and gap>=.004: trend='BULL'
    elif e20[i]<e50[i]<e200[i] and c[i]<e50[i] and gap>=.004: trend='BEAR'
    vol=sum(x['v'] for x in rows[-20:])/20 if len(rows)>=20 else float('nan')
    return {'trend':trend,'structure':structure(rows),'rsi':rr[i],'atr':aa[i],'relvol':rows[-1]['v']/vol if vol else float('nan'),'close':c[i]}


def signal_at(series, i, p):
    # series is 15m; higher frames use data up to the same timestamp, avoiding look-ahead.
    t=series[i]['t']; frames={}
    for tf,ms in [('15m',TF_MS['15m']),('1h',TF_MS['1h']),('4h',TF_MS['4h'])]:
        cutoff=(t//ms)*ms
        sub=[x for x in series if x['t']<=cutoff]
        # For 1h/4h derive from 15m closed buckets; current bucket is included only if its last 15m exists.
        if tf!='15m': sub=resample(sub,ms)
        a=analysis(sub)
        frames[tf]=a
    h4,h1,m15=frames['4h'],frames['1h'],frames['15m']
    if not h4 or not h1:return None
    direction='LONG' if h4['trend']=='BULL' else 'SHORT' if h4['trend']=='BEAR' else None
    if not direction:return None
    score=0
    if (direction=='LONG' and h1['trend']=='BULL') or (direction=='SHORT' and h1['trend']=='BEAR'): score+=30
    elif h1['trend']=='RANGE':score+=15
    if (direction=='LONG' and h4['structure']=='HH_HL') or (direction=='SHORT' and h4['structure']=='LH_LL'):score+=20
    elif h4['structure'] in ('EXPANSION','CONTRACTION'):score+=8
    r=h4['rsi'];
    if (direction=='LONG' and p['rsi_long'][0]<=r<=p['rsi_long'][1]) or (direction=='SHORT' and p['rsi_short'][0]<=r<=p['rsi_short'][1]):score+=15
    score+=10 if p['vol_mode'] and math.isfinite(h4['atr']) else 2
    if m15 and math.isfinite(m15['relvol']):score+=10 if m15['relvol']>=1.1 else 3
    if m15 and ((direction=='LONG' and m15['structure']=='HH_HL') or (direction=='SHORT' and m15['structure']=='LH_LL')):score+=15
    else:score+=4
    if score<p['min_score']:return None
    price=series[i]['c']; sl=price-(p['sl_atr']*h4['atr']) if direction=='LONG' else price+(p['sl_atr']*h4['atr'])
    tp=price+(p['tp_atr']*h4['atr']) if direction=='LONG' else price-(p['tp_atr']*h4['atr'])
    return {'dir':direction,'score':score,'entry':price,'sl':sl,'tp':tp,'atr':h4['atr']}


def backtest(rows,p,cost_mult=1.0):
    fee=.001*cost_mult; slip=.0005*cost_mult; eq=1000.; peak=eq; maxdd=0; trades=[]; i=0
    while i<len(rows)-1:
        sig=signal_at(rows,i,p)
        if not sig: i+=1; continue
        ebar=rows[i+1]; entry=ebar['o']*(1+slip if sig['dir']=='LONG' else 1-slip)
        risk=abs(entry-sig['sl']); qty=min(eq*.02/risk, eq*.50/entry)
        if qty<=0:i+=1;continue
        ef=entry*qty*fee; exitp=None; reason='EXPIRED'; hold=0
        for j in range(i+1,min(len(rows),i+1+96)):
            hold+=1;b=rows[j]
            if sig['dir']=='LONG':
                if b['l']<=sig['sl']:exitp=sig['sl']*(1-slip);reason='SL';break
                if b['h']>=sig['tp']:exitp=sig['tp']*(1-slip);reason='TP';break
            else:
                if b['h']>=sig['sl']:exitp=sig['sl']*(1+slip);reason='SL';break
                if b['l']<=sig['tp']:exitp=sig['tp']*(1+slip);reason='TP';break
        if exitp is None:
            b=rows[min(len(rows)-1,i+96)]; exitp=b['c']*(1-slip if sig['dir']=='LONG' else 1+slip)
        gross=(exitp-entry)*qty if sig['dir']=='LONG' else (entry-exitp)*qty; net=gross-ef-exitp*qty*fee
        eq+=net; peak=max(peak,eq); maxdd=max(maxdd,(peak-eq)/peak); trades.append(net); i+=max(1,hold)
    wins=sum(x>0 for x in trades); losses=sum(x<0 for x in trades); gw=sum(x for x in trades if x>0); gl=-sum(x for x in trades if x<0)
    return {'trades':len(trades),'win_rate':wins/len(trades)*100 if trades else 0,'return_pct':(eq/1000-1)*100,'max_dd_pct':maxdd*100,'profit_factor':gw/gl if gl else None,'final':eq,'net':eq-1000,'expectancy':statistics.mean(trades) if trades else 0,'trade_pnls':trades}


def mc(pnls,n=2000,seed=42):
    if not pnls:return {'runs':0}
    r=random.Random(seed); finals=[]; dds=[]
    for _ in range(n):
        seq=[r.choice(pnls) for _ in pnls]; eq=1000; peak=eq; dd=0
        for x in seq: eq+=x; peak=max(peak,eq); dd=max(dd,(peak-eq)/peak)
        finals.append(eq); dds.append(dd*100)
    finals.sort(); dds.sort()
    return {'runs':n,'p5_final':finals[int(.05*n)],'median_final':finals[int(.5*n)],'p95_dd':dds[int(.95*n)],'prob_loss':sum(x<1000 for x in finals)/n*100}


def research(rows):
    base={'sl_atr':2.5,'tp_atr':1.5,'min_score':62,'rsi_long':(40,75),'rsi_short':(25,60),'vol_mode':True}
    grid=[]
    for sl in (2.0,2.5,3.0):
      for tp in (1.25,1.5,2.0):
       for ms in (62,68,74):
        p=dict(base,sl_atr=sl,tp_atr=tp,min_score=ms); grid.append((p,backtest(rows,p)))
    # 4 chronological folds: 50% train, then four sequential OOS slices.
    n=len(rows); fold=max(1,n//8); folds=[]
    for k in range(4):
        train_end=n//2+k*fold; test_end=min(n,train_end+fold)
        if test_end-train_end<100:continue
        train=rows[:train_end]; test=rows[train_end:test_end]
        ranked=sorted(((res['net'],p,res) for p,res in ((p,backtest(train,p)) for p,_ in grid)),reverse=True,key=lambda x:x[0])
        top=ranked[:10]; oos=[]
        for _,p,_ in top:oos.append((backtest(test,p),p))
        best=max(oos,key=lambda x:x[0]['net']) if oos else None
        folds.append({'fold':k+1,'train_rows':len(train),'test_rows':len(test),'selected':best[1] if best else None,'oos':best[0] if best else None,'top10_oos':sorted([x[0]['net'] for x in oos],reverse=True)})
    baseline=backtest(rows,base)
    stresses={str(m):backtest(rows,base,m) for m in (1,1.5,2,3)}
    mcres=mc(baseline['trade_pnls'])
    return {'baseline':baseline,'grid_size':len(grid),'wfa':folds,'cost_stress':stresses,'monte_carlo':mcres}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--days',type=int,default=60); ap.add_argument('--out',default='research_results.json'); a=ap.parse_args()
    end=int(time.time()*1000); start=end-a.days*86_400_000; root=Path(a.out).parent; root.mkdir(parents=True,exist_ok=True)
    report={'generated_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'days':a.days,'assets':{}}
    for name,(provider,symbol) in ASSETS.items():
        try:
            rows=fetch_kucoin(symbol,start,end) if provider=='kucoin' else fetch_bitunix(symbol,start,end) if provider=='bitunix' else fetch_yahoo(symbol,start,end)
            v,clean=validate(rows)
            r1=research(clean) if len(clean)>=1200 else {'status':'INSUFFICIENT_DATA_FOR_WFA','rows':len(clean)}
            report['assets'][name]={'provider':provider,'symbol':symbol,'validation':v,'research':r1}
            Path(root/(name+'.json')).write_text(json.dumps({'metadata':{'asset':name,'provider':provider,'symbol':symbol},'rows':clean},indent=2))
            print('PASS',name,len(clean),'rows')
        except Exception as e:
            report['assets'][name]={'provider':provider,'symbol':symbol,'status':'BLOCKED','error':repr(e)}; print('BLOCKED',name,repr(e))
    Path(a.out).write_text(json.dumps(report,indent=2,default=str)); print('REPORT',a.out)

if __name__=='__main__':main()
