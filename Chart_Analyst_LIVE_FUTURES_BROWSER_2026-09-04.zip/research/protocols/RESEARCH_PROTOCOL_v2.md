# Chart Analyst Research Protocol v2

## Objective
Evaluate the existing Chart Analyst signal engine for robustness rather than optimize a single historical result.

## Signal source
The production `index.html` is loaded unchanged. The research runner calls the same `analyzeTimeframe()`, `buildSignal()`, and `buildFuturesSignal()` functions.

## Execution model
- Signal timestamp: close of the current 15m candle.
- Entry: next 15m candle open.
- Direction: LONG or SHORT only when production signal is `READY`.
- SL/TP: levels frozen at signal time.
- Same-candle SL/TP hit: SL wins.
- Maximum holding period: 96 × 15m = 24 hours.
- No pyramiding while a trade is open.
- Position sizing: equity risk divided by entry-to-SL distance, capped by maximum notional.
- Fees and slippage are applied on both entry and exit.

## Robustness tests
1. Time-fold stability: chronological trade partitions.
2. Cost stress: base, 1.5×, 2× and 3× fee/slippage.
3. Monte Carlo: random trade-order permutation for distribution of final equity and max drawdown.
4. Data-quality counts: H4/H1/15m bars are reported.

## Important methodological boundary
This version does **not** claim a statistically validated alpha or choose new signal parameters from the same historical sample. Parameter optimization of the signal formula must only be performed against a dedicated development dataset, followed by locked OOS validation.

## Current environment limitation
The ChatGPT execution environment used for this build has no working external DNS/network route to the market APIs. Therefore no real historical performance number is fabricated here. The HTML runner is designed to fetch the real public data when executed through the supplied local server in an environment with API access.
