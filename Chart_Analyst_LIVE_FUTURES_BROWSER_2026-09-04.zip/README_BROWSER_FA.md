# Chart Analyst — نسخه قابل اجرا در مرورگر

این بسته نسخه وبِ قابل اجرای پروژه Chart Analyst است. داشبورد اصلی از مسیر `/` باز می‌شود و برای دریافت داده‌های زنده از proxy داخلی Node استفاده می‌کند؛ بنابراین **باز کردن مستقیم فایل HTML با `file://` روش صحیح اجرای نسخه زنده نیست**.

## اجرای سریع در Android / Termux

پیش‌نیاز: Node.js 18+ در Termux.

```bash
cd chart_analyst_cursor_repo
bash tools/open-browser-termux.sh
```

سپس مرورگر Android باید خودکار باز شود. اگر خودکار باز نشد، این آدرس را در Chrome وارد کنید:

`http://127.0.0.1:8080/`

## صفحات

- `/` — داشبورد اصلی Chart Analyst
- `/apps/dashboard/live.html` — Live / Paper monitor
- `/apps/dashboard/gold-live.html` — Gold Spot / Futures monitor
- `/apps/dashboard/futures-20x.html` — Futures و کنترل اهرم 1x تا 20x
- `/apps/dashboard/research-status.html` — وضعیت Research Gate
- `/research/runner/research_v2.html` — Research runner
- `/research/runner/backtest.html` — Backtest runner

## داده‌های مورد استفاده

- BTC Spot: KuCoin
- ETH Spot: KuCoin
- BTC Futures: Bitunix public market data
- ETH Futures: Bitunix public market data
- Gold Spot: Yahoo Finance `XAUUSD=X`
- Gold Futures: Yahoo Finance `GC=F` (فقط قرارداد پیوسته برای تحلیل؛ اجرای سفارش واقعی نیست)

## نکته مهم برای معامله واقعی

این سایت صرفاً رابط مرورگر و لایه پایش/تحلیل است. Live Gate به‌صورت پیش‌فرض خاموش است و Browser مستقیماً سفارش واقعی ارسال نمی‌کند. تا زمانی که داده واقعی، WFA/OOS، stress، holdout و الزامات venue-specific تأیید نشده‌اند، وضعیت پروژه برای Live Trading **NO-GO** است.
