const {preflight}=require('../execution/live-gate');
const r=preflight(process.env);
console.log(JSON.stringify(r,null,2));
process.exit(r.ok?0:1);
