#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")/.."
PORT="${PORT:-8080}"
HOST="${HOST:-127.0.0.1}"
# Start the local web server in the background if it is not already listening.
if ! (command -v curl >/dev/null 2>&1 && curl -fsS "http://${HOST}:${PORT}/" >/dev/null 2>&1); then
  (HOST="$HOST" PORT="$PORT" node server.js > chart-analyst-server.log 2>&1 & echo $! > .chart-analyst-server.pid)
  sleep 1
fi
URL="http://${HOST}:${PORT}/"
printf '\nChart Analyst browser site: %s\n' "$URL"
if command -v am >/dev/null 2>&1; then
  am start -a android.intent.action.VIEW -d "$URL" >/dev/null 2>&1 || true
fi
