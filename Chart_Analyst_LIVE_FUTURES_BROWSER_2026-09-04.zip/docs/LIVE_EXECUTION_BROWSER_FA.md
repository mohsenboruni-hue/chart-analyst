# اجرای واقعی Futures از Browser

این نسخه امکان ارسال سفارش واقعی LONG/SHORT برای KuCoin Futures را از Browser فراهم می‌کند؛ کلیدهای API هرگز در JavaScript مرورگر قرار نمی‌گیرند.

## قراردادهای فعال
- BTC Futures: `XBTUSDTM`
- ETH Futures: `ETHUSDTM`
- فقط Market order در این مسیر
- position mode: `BOTH` (one-way)
- margin mode پیش‌فرض: `ISOLATED`
- hard cap leverage: 20x
- hard cap risk/trade: 2%
- hard cap order size: 20 contracts (قابل تنظیم پایین‌تر)

## فعال‌سازی
```bash
cp .env.example .env
```

در `.env`:
```text
TRADING_MODE=live
LIVE_TRADING_ENABLED=true
LIVE_TRADING_CONFIRM=I_UNDERSTAND_LIVE_RISK
LIVE_KILL_SWITCH=false
MAX_LEVERAGE=20
MAX_RISK_PER_TRADE=0.02
MAX_ORDER_SIZE=20
KC_API_KEY=...
KC_API_SECRET=...
KC_API_PASSPHRASE=...
KC_API_KEY_VERSION=2
```

اجرای سرور:
```bash
npm start
```
Browser:
```text
http://127.0.0.1:8080/
```

در صفحه Futures وقتی LONG/SHORT تولید شود، دکمه ارسال واقعی ظاهر می‌شود. برای جلوگیری از ارسال ناخواسته، Browser باید عبارت `SEND_REAL_ORDER` را صریحاً تأیید کند.

## محدودیت فعلی
مسیر اجرای واقعی فقط **ورود Market** را ارسال می‌کند و Stop/TP را به‌صورت اتمیک همراه ورود ارسال نمی‌کند. بنابراین فعال‌سازی آن برای سرمایه واقعی باید با اندازه بسیار محدود و پس از تأیید تنظیمات حساب انجام شود.
