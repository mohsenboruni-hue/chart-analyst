# Live Trading Readiness — 2026-09-04

Status: **NO-GO**

Live execution is disabled by default.

Before enabling real-money execution, all of the following are mandatory:
1. Real BTC/ETH Spot+Futures and Gold Spot/Futures datasets acquired and frozen.
2. Data validation PASS: timestamps, OHLC relationships, duplicates, gaps, timeframe alignment.
3. Baseline reproduction PASS.
4. Chronological WFA/OOS PASS.
5. Cost stress PASS at 1x, 1.5x, 2x and 3x modeled transaction costs.
6. Parameter perturbation PASS.
7. Monte-Carlo diagnostic completed.
8. Untouched final holdout PASS.
9. Venue-specific contract metadata verified for every executable symbol.
10. Venue-specific maintenance margin, liquidation, tick size, lot size, min order, funding and fee rules incorporated.
11. Paper trading / shadow execution PASS.
12. Kill switch, max daily loss, max concurrent exposure and stale-data gates PASS.
13. Explicit operator enablement.

Important: `GC=F` is a research data symbol for Gold futures and is not treated as an executable broker contract. An actual live Gold futures venue and contract month must be selected and verified before order routing is enabled.

20x is a hard signal-policy ceiling, not a promise that a venue supports 20x for a given instrument. Live leverage must be bounded by the venue's actual contract rules and the project's margin-safety gate.
