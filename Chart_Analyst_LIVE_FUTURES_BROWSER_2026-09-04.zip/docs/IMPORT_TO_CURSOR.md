# Import to Cursor / GitHub

## Option A — GitHub

1. Create an empty GitHub repository.
2. Copy this repository into it, preserving the directory structure.
3. Open the repository folder in Cursor.
4. Read `AGENTS.md` first.
5. Use `docs/CURSOR_WORKFLOW.md` for the first agent task.

## Option B — local/Termux

```bash
unzip chart_analyst_cursor_repo.zip -d chart-analyst
cd chart-analyst
node --version
npm run verify
PORT=8091 npm start
```

Open `http://127.0.0.1:8091/`.

## First Cursor task

Do not ask Cursor to optimize the strategy yet. Start with repository inspection and contradiction detection. Only after the baseline is understood should a bounded research implementation be authorized.
