# Repository Map

| Area | Responsibility | Change policy |
|---|---|---|
| `apps/dashboard/` | Production UI + current signal implementation | Frozen baseline until approved |
| `research/runner/` | Historical research/backtest runners | Experimental; no production side effects |
| `research/protocols/` | Validation methodology | Controlled document |
| `research/reports/` | Audit/evidence reports | Append/version; do not overwrite evidence |
| `engine/` | Reserved modular destination for future extracted logic | Populate only through approved refactor |
| `data/raw/` | Temporary raw datasets | Not committed |
| `data/validated/` | Validated datasets | Not committed by default |
| `data/frozen/` | Final frozen datasets/holdouts | Explicitly versioned when approved |
| `tests/` | Regression and invariant tests | Required for changes |
| `configs/` | Versioned configuration | No hidden parameters |
| `docs/` | Engineering/strategy contracts | Controlled |
| `tools/` | Local automation and verification | Safe/read-only by default |
| `legacy/` | Original snapshots for provenance | Never modify |
