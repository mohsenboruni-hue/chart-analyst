# Gold Market Specification

## 1. Spot
Symbol: `XAUUSD=X` (Yahoo Finance chart feed). Used for market analysis only.

## 2. Futures
Symbol: `GC=F` (continuous COMEX gold futures representation). Used for analysis only. TradingView confirms COMEX gold continuous contract `GC1!` and individual dated contracts; continuous contracts are not themselves a live execution contract. citeturn0search0turn0search1

## 3. Separation rule
Spot and futures candles/prices are never mixed inside one signal. Each market has an independent signal object.

## 4. 4H construction
Yahoo is queried natively at 1H and the 4H series is deterministically constructed from exactly four consecutive closed 1H candles aligned to UTC 4-hour boundaries. Incomplete buckets are discarded. The derived status is explicit in the normalized data; no future candle is used.

## 5. Leverage
The futures signal may recommend up to 20x under the existing score/ATR/margin-safety policy. The recommendation is not proof that a venue offers 20x on gold; venue-specific leverage and margin rules must be verified before execution.
