# GitHub / Cursor Import

The repository is self-contained and includes `.git` metadata. GitHub connection was checked on 2026-09-04; no repositories were visible to the connected GitHub account, so no remote push was performed.

## Recommended first push
```bash
git init
git add .
git commit -m "Chart Analyst V2: gold spot/futures + 20x futures + live safety architecture"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY>
git push -u origin main
```

## Cursor
Open the repository root in Cursor. `AGENTS.md` and `.cursor/rules/chart-analyst.mdc` define the implementation contract. Cursor must not change strategy logic without an explicit task and passing research gates.
