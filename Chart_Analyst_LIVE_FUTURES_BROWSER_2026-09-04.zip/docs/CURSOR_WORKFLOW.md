# Cursor Workflow

Cursor executes approved engineering tasks. It does not decide trading architecture.

## First inspection prompt

Read `AGENTS.md`, `docs/STRATEGY_SPEC.md`, `docs/RESEARCH_GATES.md`, and `research/protocols/RESEARCH_PROTOCOL_v2.md`. Do not edit code. Produce a repository map, identify the production signal functions, identify all provider/data boundaries, and list contradictions between documentation and code. Stop after findings.

## Implementation sequence
1. Inspect.
2. Produce bounded plan.
3. Obtain approval.
4. Implement one bounded change.
5. Run verification.
6. Review diff.
7. Record evidence in `research/reports/generated/`.

## Prohibited shortcuts
- No whole-app rewrite without explicit authorization.
- No invented signal model.
- No leverage added merely to increase return.
- No look-ahead/future data.
- No final-holdout tuning.
- No simulated result presented as live-market evidence.
