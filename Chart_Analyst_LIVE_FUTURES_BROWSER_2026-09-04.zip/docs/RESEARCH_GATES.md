# Research Gates

1. Data validity — timestamps, OHLC relationships, duplicates, missing bars, timeframe alignment.
2. Baseline reproduction — current engine reproduces documented behavior.
3. Development research — optimization only on designated development data.
4. Chronological WFA/OOS — no random train/test split for time series selection.
5. Cost stress — minimum 1×, 1.5×, 2× and 3× transaction-cost scenarios.
6. Parameter perturbation — nearby values must not collapse results.
7. Monte Carlo — trade-order/path stress; diagnostic, not proof of alpha.
8. Untouched final holdout — evaluate only after candidate is frozen.
9. Regression — safety and behavioral invariants remain passing.
10. Promotion decision — PASS / FAIL / INCONCLUSIVE with evidence.

Any failed gate blocks automatic promotion.
