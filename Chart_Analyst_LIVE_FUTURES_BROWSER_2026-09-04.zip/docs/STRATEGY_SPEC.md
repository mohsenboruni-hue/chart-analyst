# Chart Analyst Strategy Specification — Baseline

Status: **BASELINE / FROZEN FOR RESEARCH**

This describes the current production behavior packaged on 2026-09-04. It is not a profitability claim.

## Signal architecture

### Spot
- 4H = primary regime/direction
- 1H = confirmation
- 15m = trigger
- final domain: `LONG | SHORT | NO TRADE`

### Futures
`buildFuturesSignal()` is an independent futures signal path. It must not reuse spot candles or mix spot/futures prices.

## Execution/backtest boundary
- Signal is evaluated at the close of the current 15m candle.
- Entry is the next 15m candle open.
- Directional trades require `READY` status.
- SL/targets are frozen at signal time.
- Same-candle SL and TP: SL resolves first (conservative).
- Maximum holding period: 96 × 15m = 24 hours.
- No pyramiding while a trade is open.
- Position sizing is equity-risk based and capped by maximum notional.
- Fees and slippage apply on entry and exit.

## Provider policy
Provider verification status is part of the data contract. Unverified APIs must not be called as verified.

## Gold boundary
GOLD/XAUUSD must not receive a production LONG/SHORT signal from an unverified data path. A real XAUUSD OHLCV provider must be explicitly validated before production integration.

## Change control
Any modification creates a new strategy version. Do not overwrite this baseline to make an experiment canonical.


## V2 Futures 20x Engineering Candidate — 2026-09-04

- New candidate version; original baseline preserved at `legacy/BASELINE-2026-09-04/index.html`.
- Futures leverage may be recommended from 1x through 20x; 20x is a ceiling, not a default.
- Selection uses signal score, ATR%, and a conservative margin-safety guard.
- Internal guard: `stop_distance_pct × leverage <= 35%`. This is an engineering safety constraint, not an exchange liquidation-price formula.
- Exact venue maintenance-margin and liquidation rules must be verified before live execution.
- `confidencePct` is a signal-quality index, not a calibrated probability of success.
- No real-money execution is enabled by this change.
