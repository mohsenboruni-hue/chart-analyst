/** Gold market adapters.
 * Data semantics:
 * - Spot: XAUUSD=X (Yahoo Finance chart feed)
 * - Futures: GC=F (COMEX gold futures continuous front representation)
 * These are ANALYSIS feeds only. They are not execution venues.
 */
const GOLD_MARKETS = Object.freeze({
  GOLD_SPOT: { asset:'GOLD', market:'spot', symbol:'XAUUSD=X', display:'XAU/USD', source:'Yahoo Finance chart' },
  GOLD_FUTURES: { asset:'GOLD', market:'futures', symbol:'GC=F', display:'COMEX Gold Futures', source:'Yahoo Finance chart' }
});
function normalizeYahooChart(raw, timeframe) {
  const r = raw?.chart?.result?.[0];
  if (!r || !Array.isArray(r.timestamp) || !r.indicators?.quote?.[0]) throw new Error('Invalid Yahoo chart response');
  const q=r.indicators.quote[0];
  const out=[];
  for(let i=0;i<r.timestamp.length;i++) {
    const row={timestamp:r.timestamp[i]*1000,open:+q.open?.[i],high:+q.high?.[i],low:+q.low?.[i],close:+q.close?.[i],volume:+(q.volume?.[i] ?? 0),timeframe};
    if([row.open,row.high,row.low,row.close].every(Number.isFinite) && row.open>0&&row.high>=row.low&&row.close>0) out.push(row);
  }
  return out;
}
module.exports={GOLD_MARKETS,normalizeYahooChart};
