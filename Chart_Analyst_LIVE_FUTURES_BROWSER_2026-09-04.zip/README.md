# Chart Analyst — Engineering Repository

## Purpose

This repository is the controlled engineering workspace for Chart Analyst. The production signal logic is treated as a **frozen baseline** until a research result survives the project's validation gates.

The repository is deliberately structured so that an AI coding agent (Cursor/Codex/Claude Code/etc.) is an implementation tool, not the decision maker for strategy architecture.

## Current baseline

- Production UI/signal baseline: `apps/dashboard/index.html`
- Research runner: `research/runner/research_v2.html`
- Historical backtest UI: `research/runner/backtest.html`
- Research protocol: `research/protocols/RESEARCH_PROTOCOL_v2.md`
- Previous engineering audit: `research/reports/AUDIT_RESULT_v2.txt`

## Engineering rule

**Evidence → Verification → Finding → Decision → Implementation**

No AI agent may silently change signal formulas, risk parameters, execution assumptions, provider semantics, or validation boundaries.

## Local run

From a machine with Node.js:

```bash
npm install
npm run check
npm start
```

Then open:

- `http://127.0.0.1:8080/`
- `http://127.0.0.1:8080/research/runner/research_v2.html`
- `http://127.0.0.1:8080/research/runner/backtest.html`

Termux can use `bash tools/start-termux.sh`.

## Real-market limitation

The build environment used to package this repository did not have working external DNS/network access to the exchange APIs. Therefore this repository contains **no fabricated performance metrics**. Real-market backtests must be run in an environment with API access or against explicitly frozen datasets in `data/frozen/`.


## V2 Futures 20x status

The repository contains an engineering candidate that can recommend up to 20x futures leverage, protected by score/ATR and margin-safety gates. The original baseline is preserved under `legacy/BASELINE-2026-09-04/`.

This does not claim that 20x is profitable or safe in live execution. Venue-specific liquidation, maintenance margin, funding, fees, slippage, and contract specifications must be verified before execution.

## 2026-09-04 extension
- Gold spot analysis: XAUUSD=X
- Gold futures analysis: GC=F (continuous COMEX representation)
- Browser live Futures execution boundary added for explicit LONG/SHORT orders on KuCoin Futures; credentials remain server-side and the operator must explicitly enable live mode.
- Futures leverage hard cap: 20x.
- Browser page: `apps/dashboard/gold-live.html`.
